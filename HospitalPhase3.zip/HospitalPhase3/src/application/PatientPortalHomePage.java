package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class PatientPortalHomePage extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Patient Portal - Home");

        // Components for the home page
        Label welcomeLabel = new Label("Welcome Felix Johnson!");
        Label lastLoggedInLabel = new Label("You last logged in: 12/22/2023");

        Button scheduleAppointmentButton = new Button("Schedule An Appointment");
        Button viewPrescriptionsButton = new Button("View Prescriptions");

        // Profile picture
        Image profileImage = new Image("file:profile_picture.png"); // Replace "file:profile_picture.png" with your actual image path
        ImageView profileImageView = new ImageView(profileImage);
        profileImageView.setFitWidth(100);
        profileImageView.setFitHeight(100);

        // Upcoming Appointments table
        TableView<String> appointmentsTable = new TableView<>();
        appointmentsTable.setPlaceholder(new Label("No appointments scheduled"));
        TableColumn<String, String> appointmentNameColumn = new TableColumn<>("Appointment Name");
        TableColumn<String, String> dateColumn = new TableColumn<>("Date");
        appointmentsTable.getColumns().addAll(appointmentNameColumn, dateColumn);

        // Layout for home page content
        VBox homeLayout = new VBox(20);
        homeLayout.setAlignment(Pos.CENTER);
        homeLayout.setPadding(new Insets(20));
        homeLayout.getChildren().addAll(welcomeLabel, lastLoggedInLabel,
                                         new StackPane(profileImageView),
                                         new HBox(20, scheduleAppointmentButton, viewPrescriptionsButton),
                                         new VBox(10, new Label("My Upcoming Appointments:"), appointmentsTable));

        // Sidebar menu components
        Button homeButton = new Button("HOME");
        Button profileButton = new Button("PROFILE");
        Button healthHistoryButton = new Button("HEALTH HISTORY");
        Button appointmentsButton = new Button("APPOINTMENTS");
        Button visitSummaryButton = new Button("VISIT SUMMARY");
        Button messagesButton = new Button("MESSAGES");
        Button settingsButton = new Button("SETTINGS");
        Button logoutButton = new Button("LOG OUT");
        logoutButton.setOnAction(e -> {
        	Main main = new Main();
        	main.start(primaryStage);
        });

        // Set fixed size for all buttons in the sidebar menu
        double buttonWidth = 150;
        double buttonHeight = 40;
        homeButton.setPrefSize(buttonWidth, buttonHeight);
        profileButton.setPrefSize(buttonWidth, buttonHeight);
        healthHistoryButton.setPrefSize(buttonWidth, buttonHeight);
        appointmentsButton.setPrefSize(buttonWidth, buttonHeight);
        visitSummaryButton.setPrefSize(buttonWidth, buttonHeight);
        messagesButton.setPrefSize(buttonWidth, buttonHeight);
        settingsButton.setPrefSize(buttonWidth, buttonHeight);
        logoutButton.setPrefSize(buttonWidth, buttonHeight);

        // Layout for sidebar menu
        VBox menuLayout = new VBox(10);
        menuLayout.setPadding(new Insets(10));
        menuLayout.getChildren().addAll(homeButton, profileButton, healthHistoryButton,
                                         appointmentsButton, visitSummaryButton, messagesButton,
                                         settingsButton, logoutButton);

        // Apply blue gradient background to homeLayout
        homeLayout.setStyle("-fx-background-color: linear-gradient(to bottom, #d1e5f0, #a5cbe4);");

        // Main layout combining sidebar menu and home page content
        BorderPane mainLayout = new BorderPane();
        mainLayout.setLeft(menuLayout);
        mainLayout.setCenter(homeLayout);
        
        // Event handlers for sidebar buttons
        homeButton.setOnAction(e -> goToHome(primaryStage));
        profileButton.setOnAction(e -> goToProfile(primaryStage));
        healthHistoryButton.setOnAction(e -> goToHealthHistory(primaryStage));
        appointmentsButton.setOnAction(e -> goToAppointments(primaryStage));
        visitSummaryButton.setOnAction(e -> goToVisitSummary(primaryStage));
        messagesButton.setOnAction(e -> goToMessages(primaryStage));
        settingsButton.setOnAction(e -> goToSettings(primaryStage));
        //logoutButton.setOnAction(e -> logout(primaryStage));

        Scene scene = new Scene(mainLayout, 700, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    private void goToHome(Stage primaryStage) {
        PatientPortalHomePage homePage = new PatientPortalHomePage();
        homePage.start(primaryStage);
    }

    private void goToProfile(Stage primaryStage) {
    	PatientProfile profile = new PatientProfile();
        profile.start(primaryStage);
    }

    private void goToHealthHistory(Stage primaryStage) {
    	PatientHealthHistory PatientHH = new PatientHealthHistory();
        PatientHH.start(primaryStage);
    }

    private void goToAppointments(Stage primaryStage) {
    	PatientAppointments PatientApps = new PatientAppointments();
        PatientApps.start(primaryStage);
    }

    private void goToVisitSummary(Stage primaryStage) {
    	PatientVS patientVS= new PatientVS();
        patientVS.start(primaryStage);
    }

    private void goToMessages(Stage primaryStage) {
    	PatientMessages PMessages = new PatientMessages();
        PMessages.start(primaryStage);
    }

    private void goToSettings(Stage primaryStage) {
    	PatientSettings PSettings = new PatientSettings();
        PSettings.start(primaryStage);
    }

    private void logout(Stage primaryStage) {
        // Code to logout
        
        primaryStage.close();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
