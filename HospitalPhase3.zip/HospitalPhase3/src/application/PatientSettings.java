package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.Pos;

public class PatientSettings extends Application {

	@Override
	public void start(Stage primaryStage) {
	    // Sidebar menu components
	    Button homeButton = new Button("HOME");
	    Button profileButton = new Button("PROFILE");
	    Button healthHistoryButton = new Button("HEALTH HISTORY");
	    Button appointmentsButton = new Button("APPOINTMENTS");
	    Button visitSummaryButton = new Button("VISIT SUMMARY");
	    Button messagesButton = new Button("MESSAGES");
	    Button settingsButton = new Button("SETTINGS");
	    Button logoutButton = new Button("LOG OUT");

	    // Set fixed size for all buttons in the sidebar menu
	    double sidebarButtonWidth = 150;
	    double sidebarButtonHeight = 40;
	    homeButton.setPrefSize(sidebarButtonWidth, sidebarButtonHeight);
	    profileButton.setPrefSize(sidebarButtonWidth, sidebarButtonHeight);
	    healthHistoryButton.setPrefSize(sidebarButtonWidth, sidebarButtonHeight);
	    appointmentsButton.setPrefSize(sidebarButtonWidth, sidebarButtonHeight);
	    visitSummaryButton.setPrefSize(sidebarButtonWidth, sidebarButtonHeight);
	    messagesButton.setPrefSize(sidebarButtonWidth, sidebarButtonHeight);
	    settingsButton.setPrefSize(sidebarButtonWidth, sidebarButtonHeight);
	    logoutButton.setPrefSize(sidebarButtonWidth, sidebarButtonHeight);

	    // Layout for sidebar menu
	    VBox menuLayout = new VBox(10);
	    menuLayout.setPadding(new Insets(10));
	    menuLayout.getChildren().addAll(homeButton, profileButton, healthHistoryButton,
	                                     appointmentsButton, visitSummaryButton, messagesButton,
	                                     settingsButton, logoutButton);

	    // Event handlers for sidebar buttons
	    homeButton.setOnAction(e -> goToHome(primaryStage));
	    profileButton.setOnAction(e -> goToProfile(primaryStage));
	    healthHistoryButton.setOnAction(e -> goToHealthHistory(primaryStage));
	    appointmentsButton.setOnAction(e -> goToAppointments(primaryStage));
	    visitSummaryButton.setOnAction(e -> goToVisitSummary(primaryStage));
	    messagesButton.setOnAction(e -> goToMessages(primaryStage));
	    settingsButton.setOnAction(e -> goToSettings(primaryStage));
	    logoutButton.setOnAction(e -> logout(primaryStage));

	    // Layout for Settings Page content
	    VBox settingsContentLayout = new VBox(20);
	    settingsContentLayout.setAlignment(Pos.CENTER_LEFT);
	    settingsContentLayout.setPadding(new Insets(20));

	    // Title
	    Label titleLabel = new Label("Settings");
	    titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

	    // Settings options
	    String[] settingOptions = {
	            "Wifi & Networks", "Bluetooth and other devices", "Display and Brightness",
	            "Privacy and Security", "Language"
	    };
	    for (String option : settingOptions) {
	        Label label = new Label(option);
	        label.setStyle("-fx-padding: 10; -fx-border-style: solid inside; -fx-border-width: 1;");
	        label.setPrefWidth(300);
	        settingsContentLayout.getChildren().add(label);
	        
	    }

	    // Toggle Switch for reminders
	    ToggleButton toggleReminders = new ToggleButton("Send me reminders for appointments");
	    toggleReminders.setSelected(true);
	    settingsContentLayout.getChildren().add(toggleReminders);

	    // Back and Save buttons
	    Button backButton = new Button("Back");
	    Button saveButton = new Button("Save");
	    HBox buttonsPanel = new HBox(10, backButton, saveButton);
	    buttonsPanel.setAlignment(Pos.CENTER); // Center align the back and save buttons
	    settingsContentLayout.getChildren().addAll(buttonsPanel);

	    // Main layout with navigation and settings panels
	    HBox mainLayout = new HBox(menuLayout, settingsContentLayout);
	    mainLayout.setStyle("-fx-background-color: linear-gradient(to bottom, #d1e5f0, #a5cbe4);");

	    // Set the scene and stage
	    Scene scene = new Scene(mainLayout, 700, 500);
	    primaryStage.setScene(scene);
	    primaryStage.setTitle("Settings");
	    primaryStage.show();
	}


	
    private void goToHome(Stage primaryStage) {
        PatientPortalHomePage homePage = new PatientPortalHomePage();
        homePage.start(primaryStage);
    }

    private void goToProfile(Stage primaryStage) {
    	PatientProfile profile = new PatientProfile();
        profile.start(primaryStage);
    }

    private void goToHealthHistory(Stage primaryStage) {
    	PatientHealthHistory PatientHH = new PatientHealthHistory();
        PatientHH.start(primaryStage);
    }

    private void goToAppointments(Stage primaryStage) {
    	PatientAppointments PatientApps = new PatientAppointments();
        PatientApps.start(primaryStage);
    }

    private void goToVisitSummary(Stage primaryStage) {
    	PatientVS patientVS= new PatientVS();
        patientVS.start(primaryStage);
    }

    private void goToMessages(Stage primaryStage) {
    	PatientMessages PMessages = new PatientMessages();
        PMessages.start(primaryStage);
    }

    private void goToSettings(Stage primaryStage) {
    	PatientSettings PSettings = new PatientSettings();
        PSettings.start(primaryStage);
    }

    private void logout(Stage primaryStage) {
        // Code to logout
        System.out.println("Logging out...");
        primaryStage.close();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
