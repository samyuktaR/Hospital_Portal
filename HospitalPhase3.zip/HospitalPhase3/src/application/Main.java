package application;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.layout.HBox;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Main layout pane
        BorderPane borderPane = new BorderPane();

        Stop[] stops = new Stop[]{new Stop(0, Color.CORNFLOWERBLUE), new Stop(1, Color.WHITE)};
        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        borderPane.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #6495ED, white);");
        
        // Center buttons
        VBox centerBox = new VBox(20); // spacing between buttons
        centerBox.setAlignment(Pos.CENTER);
        
        Button patientButton = new Button("PATIENT");
        patientButton.setPrefSize(200, 50); // width, height
        patientButton.setOnAction(e -> {
        	PatientPortal patientportal = new PatientPortal();
        	patientportal.start(primaryStage);
        });
        patientButton.setStyle("-fx-background-color: white; -fx-text-fill: black;");
        
        Button staffButton = new Button("STAFF");
        staffButton.setPrefSize(200, 50); // width, height
        staffButton.setOnAction(e -> StaffLoginPortal.loginportalStaff(primaryStage));
        staffButton.setStyle("-fx-background-color: white; -fx-text-fill: black;");
        
        centerBox.getChildren().addAll(patientButton, staffButton);

        borderPane.setCenter(centerBox);

        Scene scene = new Scene(borderPane, 800, 420);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Woodbridge Pediatrics");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
