package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Stage;
import javafx.geometry.Pos;

public class DoctorSettings {
	
	public static void drSettingsPage(Stage primaryStage) {
        // Navigation panel on the left
        VBox navPanel = new VBox(10);
        navPanel.setPadding(new Insets(15));
        navPanel.setStyle("-fx-background-color: #E8E8E8;");
        navPanel.setPrefWidth(150);
        Button homeButton = new Button("HOME");	
        homeButton.setPrefWidth(150);
        homeButton.setPrefHeight(550);
        
        Button patientButton = new Button("PATIENTS");
        patientButton.setPrefWidth(150);
        patientButton.setPrefHeight(550);
        
        Button pharmacyButton  = new Button("PHARMACY");
        pharmacyButton.setPrefWidth(150);
        pharmacyButton.setPrefHeight(550);
        
        Button appButton = new Button("APPOINTMENTS");	
        appButton.setPrefWidth(150);
        appButton.setPrefHeight(550);
        
        Button messageButton = new Button("MESSAGE");
        messageButton.setPrefWidth(150);
        messageButton.setPrefHeight(550);
        
        Button profileButton = new Button("PROFILE");
        profileButton.setPrefWidth(150);
        profileButton.setPrefHeight(550);
        
        Button settingsButton = new Button("SETTINGS");		
        settingsButton.setPrefWidth(150);
        settingsButton.setPrefHeight(550);
        
        Button logOutButton = new Button("LOG OUT");
        logOutButton.setPrefWidth(150);
        logOutButton.setPrefHeight(550);

        navPanel.getChildren().addAll(homeButton, patientButton, pharmacyButton, appButton, messageButton, profileButton, settingsButton, logOutButton);
        
 patientButton.setOnAction(e -> DoctorPatientsRegistered.patientsDrView(primaryStage));
        
        
        
        pharmacyButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));
        profileButton.setOnAction(e -> DoctorProfile.drProfilePage(primaryStage));
        
        //appointmenrds
        appButton.setOnAction(e -> DoctorAppointments.appDrPage(primaryStage));
        
        
        
        //set up the messageing page
        messageButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));
        //send back to the home page
        logOutButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));

        // Center settings panel
        VBox settingsPanel = new VBox(15);
        settingsPanel.setPadding(new Insets(15));

        // Title
        Label settingsTitle = new Label("Settings");
        settingsTitle.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        // Settings options
        String[] settingOptions = {
                "Wifi & Networks", "Bluetooth and other devices", "Display and Brightness",
                "Privacy and Security", "Language"
        };
        for (String option : settingOptions) {
            Label label = new Label(option);
            label.setStyle("-fx-padding: 10; -fx-border-style: solid inside; -fx-border-width: 1;");
            label.setPrefWidth(300);
            settingsPanel.getChildren().add(label);
        }

        // Toggle Switch for reminders
        ToggleButton toggleReminders = new ToggleButton("Send me reminders for appointments");
        toggleReminders.setSelected(true);
        settingsPanel.getChildren().add(toggleReminders);

        // Back and Save buttons
        Button backButton = new Button("Back");
        Button saveButton = new Button("Save");
        HBox buttonsPanel = new HBox(10, backButton, saveButton);
        buttonsPanel.setAlignment(Pos.CENTER); // Center align the back and save buttons
        settingsPanel.getChildren().addAll(buttonsPanel);

        // Main layout with navigation and settings panels
        HBox mainLayout = new HBox(navPanel, settingsPanel);
        Stop[] stops = new Stop[]{new Stop(0, Color.LIGHTSTEELBLUE), new Stop(1, Color.WHITE)};
        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        mainLayout.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #B0C4DE, white);");

        // Set the scene and stage
        Scene scene = new Scene(mainLayout, 800, 420);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Settings");
        primaryStage.show();
    }


  
}
