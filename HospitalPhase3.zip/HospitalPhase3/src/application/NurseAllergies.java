
package application;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Stage;
public class NurseAllergies {

	public void RecepPatientAllergies(Stage primaryStage) {
        // Navigation panel on the left
        VBox navPanel = new VBox(10);
        navPanel.setPadding(new Insets(15));
        navPanel.setStyle("-fx-background-color: linear-gradient(to bottom, #FFFFFF, #E8E8E8);");
        navPanel.setStyle("-fx-background-color: #E8E8E8;");
        navPanel.setPrefWidth(150);
        String[] navButtons = {"HOME", "PATIENTS", "MESSAGE", "PROFILE", "SETTINGS", "LOG OUT"};
        for (String label : navButtons) {
            Button button = new Button(label);
            button.setPrefWidth(150);
            button.setMaxWidth(Double.MAX_VALUE);
            navPanel.getChildren().add(button);
            
            if(label.equals("HOME")) {
            	button.setOnAction(e -> NurseHomePage.homePageNurse(primaryStage));
            }
            
            if(label.equals("PATIENTS")) {
            	button.setOnAction(e -> NurseViewPateints.PatientNames(primaryStage));
            }
            
            if(label.equals("SETTINGS")) {
            	button.setOnAction(e -> NurseSettings.nurseSettingsPage(primaryStage));
            }
            
            if(label.equals("LOG OUT")) {
            	button.setOnAction(e -> {
            		Main main = new Main();
                	main.start(primaryStage);
            	});
            }
            
            if(label.equals("PROFILE")) {
            	button.setOnAction(e -> NurseProfile.nurseProfilePage(primaryStage));
            }
        }

        // Main content area for the patient exam
        VBox mainContent = new VBox(10);
        mainContent.setPadding(new Insets(15));
        mainContent.setAlignment(Pos.TOP_CENTER);
        mainContent.setStyle("-fx-background-color: linear-gradient(to bottom, #FFFFFF, #F0F8FF);");

        // Title
        Label titleLabel = new Label("PATIENT EXAM");
        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        // Text areas for Health History, Allergies, Purpose of Visit
        TextArea healthHistoryArea = new TextArea ("Health History:");
        TextArea allergiesArea = new TextArea ("Allergies:");
        TextArea purposeVisitArea = new TextArea ("Purpose of Visit:");

        // Save button
        Button saveButton = new Button("Save");
        saveButton.setStyle("-fx-font-size: 16px; -fx-background-color: #8FBC8F;");

        // Back button
        Button backButton = new Button("Back");
        backButton.setStyle("-fx-font-size: 16px;");

        // Add all elements to main content area
        mainContent.getChildren().addAll(titleLabel, healthHistoryArea, allergiesArea, purposeVisitArea, saveButton, backButton);

        // Main layout with navigation and main content
        HBox mainLayout = new HBox(navPanel, mainContent);
        Stop[] stops = new Stop[]{new Stop(0, Color.LIGHTBLUE), new Stop(1, Color.WHITE)};
        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        mainLayout.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #add8e6, white);");

        // Set the scene and stage
        Scene scene = new Scene(mainLayout, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Patient Exam");
        primaryStage.show();
    }
}