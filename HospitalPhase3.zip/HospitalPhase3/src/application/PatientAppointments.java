package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class PatientAppointments extends Application {

    private VBox appointmentCheckBoxesLayout;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Appointments");

        // Components for Appointments Page
        Label titleLabel = new Label("APPOINTMENTS");
        titleLabel.setAlignment(Pos.TOP_CENTER);
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        Button scheduleButton = new Button("Schedule an Appointment");
        scheduleButton.setAlignment(Pos.TOP_CENTER);
        scheduleButton.setStyle("-fx-font-size: 16px;");

        Label upcomingAppointmentsLabel = new Label("Upcoming Appointments");
        upcomingAppointmentsLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        // Layout to hold appointment checkboxes
        appointmentCheckBoxesLayout = new VBox(10);
        appointmentCheckBoxesLayout.setAlignment(Pos.CENTER_LEFT);
        appointmentCheckBoxesLayout.setPadding(new Insets(20));

        // Event handler for scheduleButton
        scheduleButton.setOnAction(event -> {
            // Create dialog window
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Schedule Appointment");

            VBox dialogLayout = new VBox(10);
            dialogLayout.setAlignment(Pos.CENTER);
            dialogLayout.setPadding(new Insets(20));

            // Date picker for selecting the date
            DatePicker datePicker = new DatePicker();
            datePicker.setValue(LocalDate.now());
            datePicker.setPromptText("Select Date");

            // Text field for entering appointment title
            TextField titleField = new TextField();
            titleField.setPromptText("Appointment Title");

            // Button to confirm scheduling
            Button scheduleConfirmButton = new Button("Schedule");
            scheduleConfirmButton.setOnAction(e -> {
                LocalDate selectedDate = datePicker.getValue();
                String title = titleField.getText().trim();
                if (!title.isEmpty() && selectedDate != null) {
                    // Format the date to MM/dd/yyyy
                    addAppointmentCheckBox(title, selectedDate);
                    showAlert("Appointment Scheduled", "Your appointment has been scheduled successfully.");
                    String formattedDate = selectedDate.format(DateTimeFormatter.ofPattern("MMddyyyy"));
                    // Create file name
                    String fileName = formattedDate + "_APPOINTMENTS.txt";
                    // Write appointment title to file
                    writeToFile(fileName, title);
                    dialogStage.close();
                } else {
                    showAlert("Error", "Please select a date and provide a title for the appointment.");
                }
            });

            dialogLayout.getChildren().addAll(datePicker, titleField, scheduleConfirmButton);

            Scene dialogScene = new Scene(dialogLayout, 300, 200);
            dialogStage.setScene(dialogScene);
            dialogStage.show();
        });

        // Sidebar menu components
        Button homeButton = new Button("HOME");
        Button profileButton = new Button("PROFILE");
        Button healthHistoryButton = new Button("HEALTH HISTORY");
        Button appointmentsButton = new Button("APPOINTMENTS");
        Button visitSummaryButton = new Button("VISIT SUMMARY");
        Button messagesButton = new Button("MESSAGES");
        Button settingsButton = new Button("SETTINGS");
        Button logoutButton = new Button("LOG OUT");

        // Set fixed size for all buttons in the sidebar menu
        double buttonWidth = 150;
        double buttonHeight = 40;
        homeButton.setPrefSize(buttonWidth, buttonHeight);
        profileButton.setPrefSize(buttonWidth, buttonHeight);
        healthHistoryButton.setPrefSize(buttonWidth, buttonHeight);
        appointmentsButton.setPrefSize(buttonWidth, buttonHeight);
        visitSummaryButton.setPrefSize(buttonWidth, buttonHeight);
        messagesButton.setPrefSize(buttonWidth, buttonHeight);
        settingsButton.setPrefSize(buttonWidth, buttonHeight);
        logoutButton.setPrefSize(buttonWidth, buttonHeight);

        // Layout for sidebar menu
        VBox menuLayout = new VBox(10);
        menuLayout.setPadding(new Insets(10));
        menuLayout.getChildren().addAll(homeButton, profileButton, healthHistoryButton,
                                         appointmentsButton, visitSummaryButton, messagesButton,
                                         settingsButton, logoutButton);

        // Layout for Appointments Page content
        VBox appointmentsContentLayout = new VBox(20);
        appointmentsContentLayout.setAlignment(Pos.TOP_CENTER);
        appointmentsContentLayout.setPadding(new Insets(20));
        appointmentsContentLayout.setStyle("-fx-background-color: linear-gradient(to bottom, #d1e5f0, #a5cbe4);");
        appointmentsContentLayout.getChildren().addAll(titleLabel, scheduleButton, upcomingAppointmentsLabel, appointmentCheckBoxesLayout);

        // BorderPane to hold the sidebar and content
        BorderPane mainLayout = new BorderPane();
        mainLayout.setLeft(menuLayout);
        mainLayout.setCenter(appointmentsContentLayout);

        // Event handlers for sidebar buttons
        homeButton.setOnAction(e -> goToHome(primaryStage));
        profileButton.setOnAction(e -> goToProfile(primaryStage));
        healthHistoryButton.setOnAction(e -> goToHealthHistory(primaryStage));
        appointmentsButton.setOnAction(e -> goToAppointments(primaryStage));
        visitSummaryButton.setOnAction(e -> goToVisitSummary(primaryStage));
        messagesButton.setOnAction(e -> goToMessages(primaryStage));
        settingsButton.setOnAction(e -> goToSettings(primaryStage));
        logoutButton.setOnAction(e -> logout(primaryStage));

        Scene scene = new Scene(mainLayout, 700, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void addAppointmentCheckBox(String title, LocalDate date) {
        String checkBoxText = title + " (" + date.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")) + ")";
        CheckBox appointmentCheckBox = new CheckBox(checkBoxText);
        appointmentCheckBoxesLayout.getChildren().add(appointmentCheckBox);
    }

    private void goToHome(Stage primaryStage) {
        PatientPortalHomePage homePage = new PatientPortalHomePage();
        homePage.start(primaryStage);
    }

    private void goToProfile(Stage primaryStage) {
        PatientProfile profile = new PatientProfile();
        profile.start(primaryStage);
    }

    private void goToHealthHistory(Stage primaryStage) {
        PatientHealthHistory PatientHH = new PatientHealthHistory();
        PatientHH.start(primaryStage);
    }

    private void goToAppointments(Stage primaryStage) {
        PatientAppointments PatientApps = new PatientAppointments();
        PatientApps.start(primaryStage);
    }

    private void goToVisitSummary(Stage primaryStage) {
        PatientVS patientVS= new PatientVS();
        patientVS.start(primaryStage);
    }

    private void goToMessages(Stage primaryStage) {
        PatientMessages PMessages = new PatientMessages();
        PMessages.start(primaryStage);
    }

    private void goToSettings(Stage primaryStage) {
        PatientSettings PSettings = new PatientSettings();
        PSettings.start(primaryStage);
    }

    private void logout(Stage primaryStage) {
        // Code to logout
        System.out.println("Logging out...");
        primaryStage.close();
    }

    private void writeToFile(String fileName, String content) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName, true))) {
            writer.println(content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
