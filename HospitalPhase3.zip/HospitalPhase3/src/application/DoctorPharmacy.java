package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Stage;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
public class DoctorPharmacy {
	
    public static void pharmacyView(Stage primaryStage) {
        // Left navigation panel
        VBox navPanel = new VBox(10);
        navPanel.setPadding(new Insets(15));
        navPanel.setStyle("-fx-background-color: #E8E8E8;");
        navPanel.setPrefWidth(150);
        VBox vBoxLeft = new VBox(10);
        vBoxLeft.setPadding(new Insets(15));
       
        Button homeButton = new Button("HOME");	
        homeButton.setPrefWidth(150);
        homeButton.setPrefHeight(550);
        
        Button patientButton = new Button("PATIENTS");
        patientButton.setPrefWidth(150);
        patientButton.setPrefHeight(550);
        
        Button pharmacyButton  = new Button("PHARMACY");
        pharmacyButton.setPrefWidth(150);
        pharmacyButton.setPrefHeight(550);
        
        Button appButton = new Button("APPOINTMENTS");	
        appButton.setPrefWidth(150);
        appButton.setPrefHeight(550);
        
        Button messageButton = new Button("MESSAGE");
        messageButton.setPrefWidth(150);
        messageButton.setPrefHeight(550);
        
        Button profileButton = new Button("PROFILE");
        profileButton.setPrefWidth(150);
        profileButton.setPrefHeight(550);
        
        Button settingsButton = new Button("SETTINGS");		
        settingsButton.setPrefWidth(150);
        settingsButton.setPrefHeight(550);
        
        Button logOutButton = new Button("LOG OUT");
        logOutButton.setPrefWidth(150);
        logOutButton.setPrefHeight(550);

        navPanel.getChildren().addAll(homeButton, patientButton, pharmacyButton, appButton, messageButton, profileButton, settingsButton, logOutButton);
        
        patientButton.setOnAction(e -> DoctorPatientsRegistered.patientsDrView(primaryStage));
        
        
        
        pharmacyButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));
        profileButton.setOnAction(e -> DoctorProfile.drProfilePage(primaryStage));
        settingsButton.setOnAction(e -> DoctorSettings.drSettingsPage(primaryStage));
        
        //appointmenrds
        appButton.setOnAction(e -> DoctorAppointments.appDrPage(primaryStage));
        
        
        
        //set up the messageing page
        messageButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));
        //send back to the home page
        logOutButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));

        
        
        // Center form panel for prescription
        VBox formPanel = new VBox(15);
        formPanel.setPadding(new Insets(15));

        // Title for the prescription section
        Label prescriptionTitle = new Label("Prescription");
        prescriptionTitle.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        // Text field for patient's name
        TextField patientIDField = new TextField();
        patientIDField.setPromptText("Enter patient's ID");
       
        TextField patientIDName = new TextField();
        patientIDName.setPromptText("Enter patient's Name");

        TextField pharmacyNameField = new TextField();
        pharmacyNameField.setPromptText("Enter pharmacy's email");
        
        // Text area for prescription details
        TextArea prescriptionTextArea = new TextArea();
        prescriptionTextArea.setPromptText("Enter prescription");
        prescriptionTextArea.setPrefHeight(200);

        // Send button
        Button sendButton = new Button("Send to Pharmacy");
        sendButton.setOnAction(e -> {
            System.out.println("Medicine list has been sent to pharmacy");
            
            // Writing directly inside setOnAction
            String patientID = patientIDField.getText();
            String PName = pharmacyNameField.getText();
            String fileName = patientID + "_prescriptions.txt";
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            	writer.write("Pharmacy email:" + PName + "\n");
                writer.write(prescriptionTextArea.getText() + "\n\n"); // Add prescription text and newlines for separation
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
        
        
        // Back button (just for UI, no functionality)
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> DoctorHomePage.doctorPOV(primaryStage));

        // Adding all elements to the form panel
        formPanel.getChildren().addAll(prescriptionTitle,patientIDName, patientIDField, pharmacyNameField, prescriptionTextArea, sendButton, backButton);

        // Main layout
        HBox mainLayout = new HBox(navPanel, formPanel);
        Stop[] stops = new Stop[]{new Stop(0, Color.LIGHTSTEELBLUE), new Stop(1, Color.WHITE)};
        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        mainLayout.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #B0C4DE, white);");

        // Set the scene and show the stage
        Scene scene = new Scene(mainLayout, 800, 420);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Pharmacy Prescription Form");
        primaryStage.show();
    }

  
}
