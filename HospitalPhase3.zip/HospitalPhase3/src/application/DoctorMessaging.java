package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.control.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.File;
import javafx.beans.value.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class DoctorMessaging {
	
	public static void messagePatient(Stage primaryStage) {
		try {
			StackPane root = new StackPane();
			Scene scene = new Scene(root,800,420);
            scene.getStylesheets().add(DoctorMessaging.class.getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			
			
			Button patient = new Button("Patient");
			Button doctor = new Button("Doctor");
			root.getChildren().add(patient);
			root.getChildren().add(doctor);
			doctor.setTranslateY(50);
			
			patient.setOnAction(e->{
			
				StackPane r2 = new StackPane();
				Scene scene2 = new Scene(r2, 800, 420);
	            scene.getStylesheets().add(DoctorMessaging.class.getResource("application.css").toExternalForm());
				Stage secondStage = new Stage();
				secondStage.setScene(scene2);
				secondStage.show();
				
				
				TextArea messages = new TextArea();
				messages.setMaxSize(400, 500);
				messages.setTranslateY(-50);
				
				TextField input = new TextField();
				input.setMaxWidth(200);
				input.setTranslateY(250);

				Button send = new Button();
				send.setTranslateY(250);
				send.setTranslateX(-150);
				send.setText("Send");
				Button refresh = new Button();
				refresh.setTranslateY(250);
				refresh.setTranslateX(150);
				refresh.setText("Refresh");
				
				r2.getChildren().add(send);
				r2.getChildren().add(messages);
				r2.getChildren().add(input);
				r2.getChildren().add(refresh);
				try
				{
					
				
				File messageFile = new File("12345Messages.txt");
				
				Scanner messageReader = new Scanner(messageFile);
				String text;
				while (messageReader.hasNextLine()) {
					text = messageReader.nextLine();
					messages.appendText(text + "\n");
					if (messageReader.hasNextLine() == false) {
						Thread.sleep(1000);
					}
				}
				EventHandler<ActionEvent> refreshEvent = new EventHandler<ActionEvent>() {
					public void handle(ActionEvent e) {
						messages.setText("");
						try {
						Scanner refreshReader = new Scanner(messageFile);
						String text;
						while (refreshReader.hasNextLine()) {
							text = refreshReader.nextLine();
							messages.appendText(text + "\n");
						}
						refreshReader.close();
						}
						catch (Exception c) {
							
						}
					}
				};
				refresh.setOnAction(refreshEvent);
				EventHandler<ActionEvent> sendEvent = new EventHandler<ActionEvent>() {
					public void handle(ActionEvent e) {
						messages.appendText("Patient: " + input.getText()+"\n");
						try {
							FileWriter messageWrite = new FileWriter(messageFile,true);
							messageWrite.write("Patient: " + input.getText() + "\n");
							messageWrite.close();
						}
						catch(Exception b) {
							System.out.println("doctor listener error");
						}
						
					}
				};
				send.setOnAction(sendEvent);
				messageReader.close();
				}
				catch(Exception a) {
					a.printStackTrace();
				}
				

			});
			
			doctor.setOnAction(e->{
				
				StackPane r3 = new StackPane();
				Scene scene3 = new Scene(r3,600,600);
	            scene.getStylesheets().add(DoctorMessaging.class.getResource("application.css").toExternalForm());
				Stage thirdStage = new Stage();
				thirdStage.setScene(scene3);
				thirdStage.show();
				
				TextArea messages = new TextArea();
				messages.setMaxSize(400, 500);
				messages.setTranslateY(-50);
				
				TextField input = new TextField();
				input.setMaxWidth(200);
				input.setTranslateY(250);

				Button send = new Button();
				send.setTranslateY(250);
				send.setTranslateX(-150);
				send.setText("Send");
				Button refresh = new Button();
				refresh.setTranslateY(250);
				refresh.setTranslateX(150);
				refresh.setText("Refresh");
				
				r3.getChildren().add(send);
				r3.getChildren().add(messages);
				r3.getChildren().add(input);
				r3.getChildren().add(refresh);
				try
				{
					
				
				File messageFile = new File("12345Messages.txt");
				
				Scanner messageReader = new Scanner(messageFile);
				String text;
				while (messageReader.hasNextLine()) {
					text = messageReader.nextLine();
					messages.appendText(text + "\n");
				}
				EventHandler<ActionEvent> refreshEvent = new EventHandler<ActionEvent>() {
					public void handle(ActionEvent e) {
						messages.setText("");
						try {
						Scanner refreshReader = new Scanner(messageFile);
						String text;
						while (refreshReader.hasNextLine()) {
							text = refreshReader.nextLine();
							messages.appendText(text + "\n");
						}
						refreshReader.close();
						}
						catch (Exception c) {
							
						}
					}
				};
				refresh.setOnAction(refreshEvent);
				EventHandler<ActionEvent> sendEvent = new EventHandler<ActionEvent>() {
					public void handle(ActionEvent e) {
						messages.appendText("Doctor: " + input.getText()+"\n");
						try {
							FileWriter messageWrite = new FileWriter(messageFile,true);
							messageWrite.write("Doctor: " + input.getText() + "\n");
							messageWrite.close();
						}
						catch(Exception b) {
							System.out.println("doctor listener error");
						}
						
					}
				};
				send.setOnAction(sendEvent);
				messageReader.close();
				}
				catch(Exception a) {
					a.printStackTrace();
				}
				
			});
			
		} 
		
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
