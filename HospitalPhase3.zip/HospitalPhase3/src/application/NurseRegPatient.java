

package application;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class NurseRegPatient {

    private static String generatePatientID() {
        Random random = new Random();
        int min = 10000; // Minimum 5-digit number
        int max = 99999; // Maximum 5-digit number
        int id = random.nextInt(max - min + 1) + min;
        return String.format("%05d", id); // Ensure 5 digits with leading zeros if necessary
    }

    public static void storePatientData(String patientID, String name, int age, double height, double weight, double bodyTemp, String BP) {
        String fileName = patientID + "_PatientInfo.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write("Patient ID: " + patientID + "\n");
            writer.write("Name: " + name + "\n");
            writer.write("Age: " + age + "\n");
            writer.write("Height (cm): " + height + "\n");
            writer.write("Weight (Kg): " + weight + "\n");
            writer.write("Body Temperature (F): " + bodyTemp + "\n");
            writer.write("Blood Pressure: " + BP + "\n\n");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private static void addPatientName(String patientID, String name) {
        String fileName = "RegisteredPatientNames.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write(patientID + " - " + name + "\n");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static void patientRecepPage(Stage primaryStage) {
        // Sidebar with buttons
        VBox sidebar = new VBox();
        sidebar.setPadding(new Insets(10));
        sidebar.setSpacing(8);
        Button homeButton = new Button("HOME");
        Button patientsButton = new Button("PATIENTS");
        Button messageButton = new Button("MESSAGE");
        Button profileButton = new Button("PROFILE");
        Button settingsButton = new Button("SETTINGS");
        Button logOutButton = new Button("LOG OUT");
        sidebar.getChildren().addAll(homeButton, patientsButton, messageButton, profileButton, settingsButton, logOutButton);
        for (Button button : sidebar.getChildren().stream().filter(Button.class::isInstance).map(Button.class::cast).toArray(Button[]::new)) {
            button.setPrefSize(120, 50);
            VBox.setMargin(button, new Insets(0, 0, 0, 10));
        }

        logOutButton.setOnAction(e -> {
            Main main = new Main();
            main.start(primaryStage);
        });

        profileButton.setOnAction(e -> NurseProfile.nurseProfilePage(primaryStage));

        patientsButton.setOnAction(e -> NurseViewPateints.PatientNames(primaryStage));

        settingsButton.setOnAction(e -> NurseSettings.nurseSettingsPage(primaryStage));

        homeButton.setOnAction(e -> NurseHomePage.homePageNurse(primaryStage));

        // Registration grid
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        Label titleLabel = new Label("REGISTER NEW PATIENT");
        titleLabel.setStyle("-fx-font-size: 16pt; -fx-font-weight: bold;");
        GridPane.setHalignment(titleLabel, HPos.CENTER);
        GridPane.setMargin(titleLabel, new Insets(20, 0, 20, 0));

        grid.add(titleLabel, 0, 0, 2, 1);

        TextField nameField = new TextField();
        grid.add(new Label("Name:"), 0, 3);
        grid.add(nameField, 1, 3);

        TextField ageField = new TextField();
        grid.add(new Label("Age:"), 0, 4);
        grid.add(ageField, 1, 4);

        CheckBox underTwelve = new CheckBox("Under 12 years");
        grid.add(underTwelve, 2, 4);

        TextField heightField = new TextField();
        grid.add(new Label("Height (cm):"), 0, 5);
        grid.add(heightField, 1, 5);

        TextField weightField = new TextField();
        grid.add(new Label("Weight (Kg):"), 0, 6);
        grid.add(weightField, 1, 6);

        TextField bodyTemperatureField = new TextField();
        grid.add(new Label("Body Temperature (F):"), 0, 7);
        grid.add(bodyTemperatureField, 1, 7);

        TextField bloodPressureField = new TextField();
        grid.add(new Label("Blood Pressure:"), 0, 8);
        grid.add(bloodPressureField, 1, 8);

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> NurseViewPateints.PatientNames(primaryStage));
        grid.add(backButton, 0, 10);

        Button registerButton = new Button("Register");
        grid.add(registerButton, 1, 10);
        GridPane.setHalignment(registerButton, HPos.RIGHT);
        registerButton.setOnAction(e -> {
            String patientID = generatePatientID();
            String name = nameField.getText();
            int age = Integer.parseInt(ageField.getText());
            double height = Double.parseDouble(heightField.getText());
            double weight = Double.parseDouble(weightField.getText());
            double bodyTemperature = Double.parseDouble(bodyTemperatureField.getText());
            String bloodPressure = bloodPressureField.getText();

            // Determine age group based on checkbox selection
            String ageGroup = underTwelve.isSelected() ? "Under 12 years" : "Over 12 years";

            // Display the retrieved information on the screen
            TextArea displayArea = new TextArea();
            displayArea.setEditable(false);
            displayArea.appendText("Patient ID: " + patientID + "\n");
            displayArea.appendText("Name: " + name + "\n");
            displayArea.appendText("Age: " + age + "\n");
            displayArea.appendText("Age Group: " + ageGroup + "\n");
            displayArea.appendText("Height (cm): " + height + "\n");
            displayArea.appendText("Weight (Kg): " + weight + "\n");
            displayArea.appendText("Body Temperature (F): " + bodyTemperature + "\n");
            displayArea.appendText("Blood Pressure: " + bloodPressure);

            storePatientData(patientID, name, age, height, weight, bodyTemperature, bloodPressure);

            addPatientName(patientID, name);

            Button okButton = new Button("OK");
            okButton.setOnAction(event -> NurseViewPateints.PatientNames(primaryStage));
            okButton.setPrefHeight(50);
            okButton.setPrefWidth(50);

            // Create a new scene to display the information
            VBox displayLayout = new VBox(displayArea, okButton);
            Scene displayScene = new Scene(displayLayout, 400, 300);

            // Set the stage to display the new scene
            primaryStage.setScene(displayScene);
        });

        // Main layout
        HBox mainLayout = new HBox(sidebar, grid);
        mainLayout.setSpacing(10);
        Stop[] stops = new Stop[]{new Stop(0, Color.LIGHTBLUE), new Stop(1, Color.WHITE)};
        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        mainLayout.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #add8e6, white);");

        // Scene and stage setup
        Scene scene = new Scene(mainLayout, 650, 450);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Patient Registration");
        primaryStage.show();
    }
}