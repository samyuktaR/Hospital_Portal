package application;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Stage;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.List;
import java.io.File;
import java.io.*;
import javafx.scene.control.Alert;

public class DoctorPatientsRegistered {
	public static void patientsDrView(Stage stage) {
		VBox leftColumn = new VBox(10);
		leftColumn.setPadding(new Insets(15));
		Button homeButton = new Button("HOME");	
        homeButton.setPrefWidth(150);
        homeButton.setPrefHeight(550);
        
        Button patientButton = new Button("PATIENTS");
        patientButton.setPrefWidth(150);
        patientButton.setPrefHeight(550);
        
        Button pharmacyButton  = new Button("PHARMACY");
        pharmacyButton.setPrefWidth(150);
        pharmacyButton.setPrefHeight(550);
        
        Button appButton = new Button("APPOINTMENTS");	
        appButton.setPrefWidth(150);
        appButton.setPrefHeight(550);
        
        Button messageButton = new Button("MESSAGE");
        messageButton.setPrefWidth(150);
        messageButton.setPrefHeight(550);
        
        Button profileButton = new Button("PROFILE");
        profileButton.setPrefWidth(150);
        profileButton.setPrefHeight(550);
        
        Button settingsButton = new Button("SETTINGS");		
        settingsButton.setPrefWidth(150);
        settingsButton.setPrefHeight(550);
        
        Button logOutButton = new Button("LOG OUT");
        logOutButton.setPrefWidth(150);
        logOutButton.setPrefHeight(550);

        leftColumn.getChildren().addAll(homeButton, patientButton, pharmacyButton, appButton, messageButton, profileButton, settingsButton, logOutButton);
        
        //show the patient list
        patientButton.setOnAction(e -> DoctorPatientsRegistered.patientsDrView(stage));
        
        
        homeButton.setOnAction(e -> DoctorHomePage.doctorPOV(stage));
        pharmacyButton.setOnAction(e -> DoctorPharmacy.pharmacyView(stage));
        profileButton.setOnAction(e -> DoctorProfile.drProfilePage(stage));
        settingsButton.setOnAction(e -> DoctorSettings.drSettingsPage(stage));
        
        //appointments
        appButton.setOnAction(e -> DoctorAppointments.appDrPage(stage));
        
        
        
        //set up the messageing page
        messageButton.setOnAction(e -> DoctorPharmacy.pharmacyView(stage));
        //send back to the home page
        logOutButton.setOnAction(e -> DoctorPharmacy.pharmacyView(stage));
       
		
		VBox rightColumn = new VBox(10);
		rightColumn.setPadding(new Insets(15));
        
        Label welcomeLabel = new Label("Patients");
        welcomeLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        rightColumn.getChildren().add(welcomeLabel);
        
        TextArea searchBar = new TextArea();
        searchBar.setPromptText("Enter Patient ID to search");
        searchBar.setPrefHeight(5);
        
        Button searchPatient = new Button("Search");
        searchPatient.setOnAction(e -> {
            String patientInfoFileName = searchBar.getText() + "_PatientInfo.txt";
            File patientInfoFile = new File(patientInfoFileName);
            if (patientInfoFile.exists() && !searchBar.getText().trim().isEmpty()) {
                // Read the content of the file
                String content = "";
                try {
                    content = new String(Files.readAllBytes(Paths.get(patientInfoFileName)));
                } catch (IOException ex) {
                    ex.printStackTrace();
                    // You can alert the user that there was an error reading the file.
                    content = "Error reading patient info.";
                }

                // Display the content in an alert dialog
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Patient Information");
                alert.setHeaderText("Information for Patient ID: " + searchBar.getText());

                TextArea textArea = new TextArea(content.toString());
                textArea.setEditable(false);
                textArea.setWrapText(true);
                alert.getDialogPane().setContent(textArea);

                alert.showAndWait();
            }
        });
		    
        
        
        ListView<String> patientList = new ListView<>();
        try {
            // Replace "RegisteredPatientNames.txt" with the correct path if needed
            List<String> names = Files.readAllLines(Paths.get("RegisteredPatientNames.txt"));
            patientList.getItems().addAll(names);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception here
        }
        patientList.setPrefHeight(200);
        patientList.setOnMouseClicked(event -> {
            String selectedName = patientList.getSelectionModel().getSelectedItem();
            if(selectedName !=null) {
                System.out.println("Name clicked: " + selectedName);
            }
        });
        
        Button addButton = new Button("Add New");
        addButton.setOnAction(e -> NurseRegPatient.patientRecepPage(stage));
        
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> DoctorHomePage.doctorPOV(stage));
        HBox notesButtons = new HBox(20, backButton);
        
        rightColumn.getChildren().addAll(searchBar, searchPatient, patientList, notesButtons);
        
        HBox mainLayout = new HBox(0, leftColumn, rightColumn);
        Stop[] stops = new Stop[]{new Stop(0, Color.LIGHTSTEELBLUE), new Stop(1, Color.WHITE)};
        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        mainLayout.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #B0C4DE, white);");
        
        Scene scene = new Scene(mainLayout, 800, 420);
        stage.setScene(scene);
        stage.setTitle("Doctor's Portal");
        stage.show();
        
       
	}
}