package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.*;

public class PatientProfile extends Application {

    private static final String PROFILE_FILE_PATH = "profile.txt";

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Profile");

        // Components for Profile Page
        Label titleLabel = new Label("MY PROFILE");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        Label permissionLabel = new Label("You are allowed to view and edit your personal profile data.");
        permissionLabel.setStyle("-fx-font-size: 14px;");

        Label nameLabel = new Label("NAME:");
        TextField nameField = new TextField();

        Label ageLabel = new Label("AGE:");
        TextField ageField = new TextField();

        Label genderLabel = new Label("GENDER:");
        TextField genderField = new TextField();

        Label dobLabel = new Label("DATE OF BIRTH:");
        TextField dobField = new TextField();

        Label emailLabel = new Label("EMAIL ADDRESS:");
        TextField emailField = new TextField();

        Label contactLabel = new Label("CONTACT NUMBER:");
        TextField contactField = new TextField();

        Label addressLabel = new Label("HOME ADDRESS:");
        TextField addressField = new TextField();

        Label emergencyLabel = new Label("EMERGENCY CONTACT:");
        TextField emergencyField = new TextField();

        Button updateButton = new Button("UPDATE");

        // Load profile data from file
        loadProfileData(nameField, ageField, genderField, dobField, emailField, contactField, addressField, emergencyField);

        // Event handler for update button
        updateButton.setOnAction(e -> {
            saveProfileData(nameField.getText(), ageField.getText(), genderField.getText(), dobField.getText(),
                    emailField.getText(), contactField.getText(), addressField.getText(), emergencyField.getText());
        });

        // Sidebar menu components
        Button homeButton = new Button("HOME");
        Button profileButton = new Button("PROFILE");
        Button healthHistoryButton = new Button("HEALTH HISTORY");
        Button appointmentsButton = new Button("APPOINTMENTS");
        Button visitSummaryButton = new Button("VISIT SUMMARY");
        Button messagesButton = new Button("MESSAGES");
        Button settingsButton = new Button("SETTINGS");
        Button logoutButton = new Button("LOG OUT");

        // Set fixed size for all buttons in the sidebar menu
        double buttonWidth = 150;
        double buttonHeight = 40;
        homeButton.setPrefSize(buttonWidth, buttonHeight);
        profileButton.setPrefSize(buttonWidth, buttonHeight);
        healthHistoryButton.setPrefSize(buttonWidth, buttonHeight);
        appointmentsButton.setPrefSize(buttonWidth, buttonHeight);
        visitSummaryButton.setPrefSize(buttonWidth, buttonHeight);
        messagesButton.setPrefSize(buttonWidth, buttonHeight);
        settingsButton.setPrefSize(buttonWidth, buttonHeight);
        logoutButton.setPrefSize(buttonWidth, buttonHeight);

        // Layout for sidebar menu
        VBox menuLayout = new VBox(10);
        menuLayout.setPadding(new Insets(10));
        menuLayout.getChildren().addAll(homeButton, profileButton, healthHistoryButton,
                                         appointmentsButton, visitSummaryButton, messagesButton,
                                         settingsButton, logoutButton);

        // GridPane to hold profile data
        GridPane profileGrid = new GridPane();
        profileGrid.setAlignment(Pos.CENTER);
        profileGrid.setHgap(10);
        profileGrid.setVgap(10);
        profileGrid.setPadding(new Insets(20));
        profileGrid.add(nameLabel, 0, 0);
        profileGrid.add(nameField, 1, 0);
        profileGrid.add(ageLabel, 0, 1);
        profileGrid.add(ageField, 1, 1);
        profileGrid.add(genderLabel, 0, 2);
        profileGrid.add(genderField, 1, 2);
        profileGrid.add(dobLabel, 0, 3);
        profileGrid.add(dobField, 1, 3);
        profileGrid.add(emailLabel, 0, 4);
        profileGrid.add(emailField, 1, 4);
        profileGrid.add(contactLabel, 0, 5);
        profileGrid.add(contactField, 1, 5);
        profileGrid.add(addressLabel, 0, 6);
        profileGrid.add(addressField, 1, 6);
        profileGrid.add(emergencyLabel, 0, 7);
        profileGrid.add(emergencyField, 1, 7);

        // Layout for Profile Page content
        VBox profileContentLayout = new VBox(20);
        profileContentLayout.setAlignment(Pos.CENTER);
        profileContentLayout.setPadding(new Insets(20));
        profileContentLayout.getChildren().addAll(titleLabel, permissionLabel, profileGrid, updateButton);
        profileContentLayout.setStyle("-fx-background-color: linear-gradient(to bottom, #d1e5f0, #a5cbe4);");
        
        // BorderPane to hold the sidebar and content
        BorderPane mainLayout = new BorderPane();
        mainLayout.setLeft(menuLayout);
        mainLayout.setCenter(profileContentLayout);

        // Event handlers for sidebar buttons
        homeButton.setOnAction(e -> goToHome(primaryStage));
        profileButton.setOnAction(e -> goToProfile(primaryStage));
        healthHistoryButton.setOnAction(e -> goToHealthHistory(primaryStage));
        appointmentsButton.setOnAction(e -> goToAppointments(primaryStage));
        visitSummaryButton.setOnAction(e -> goToVisitSummary(primaryStage));
        messagesButton.setOnAction(e -> goToMessages(primaryStage));
        settingsButton.setOnAction(e -> goToSettings(primaryStage));
        logoutButton.setOnAction(e -> logout(primaryStage));

        Scene scene = new Scene(mainLayout, 700, 500);
        
        // Apply light blue gradient background
        scene.setFill(Color.LIGHTBLUE.interpolate(Color.WHITE, 0.5));

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void loadProfileData(TextField nameField, TextField ageField, TextField genderField, TextField dobField,
                                 TextField emailField, TextField contactField, TextField addressField, TextField emergencyField) {
        try (BufferedReader reader = new BufferedReader(new FileReader(PROFILE_FILE_PATH))) {
            String line;
            int lineIndex = 0;
            while ((line = reader.readLine()) != null) {
                switch (lineIndex) {
                    case 0:
                        nameField.setText(line);
                        break;
                    case 1:
                        ageField.setText(line);
                        break;
                    case 2:
                        genderField.setText(line);
                        break;
                    case 3:
                        dobField.setText(line);
                        break;
                    case 4:
                        emailField.setText(line);
                        break;
                    case 5:
                        contactField.setText(line);
                        break;
                    case 6:
                        addressField.setText(line);
                        break;
                    case 7:
                        emergencyField.setText(line);
                        break;
                    default:
                        // Ignore additional lines
                        break;
                }
                lineIndex++;
            }
        } catch (IOException e) {
            e.printStackTrace();
            // Handle file reading error
        }
    }

    private void saveProfileData(String name, String age, String gender, String dob,
                                 String email, String contact, String address, String emergencyContact) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PROFILE_FILE_PATH))) {
            writer.write(name + "\n");
            writer.write(age + "\n");
            writer.write(gender + "\n");
            writer.write(dob + "\n");
            writer.write(email + "\n");
            writer.write(contact + "\n");
            writer.write(address + "\n");
            writer.write(emergencyContact + "\n");
        } catch (IOException e) {
            e.printStackTrace();
            // Handle file writing error
        }
    }

    private void goToHome(Stage primaryStage) {
        PatientPortalHomePage homePage = new PatientPortalHomePage();
        homePage.start(primaryStage);
    }

    private void goToProfile(Stage primaryStage) {
        PatientProfile profile = new PatientProfile();
        profile.start(primaryStage);
    }

    private void goToHealthHistory(Stage primaryStage) {
        PatientHealthHistory PatientHH = new PatientHealthHistory();
        PatientHH.start(primaryStage);
    }

    private void goToAppointments(Stage primaryStage) {
        PatientAppointments PatientApps = new PatientAppointments();
        PatientApps.start(primaryStage);
    }

    private void goToVisitSummary(Stage primaryStage) {
        PatientVS patientVS = new PatientVS();
        patientVS.start(primaryStage);
    }

    private void goToMessages(Stage primaryStage) {
        PatientMessages PMessages = new PatientMessages();
        PMessages.start(primaryStage);
    }

    private void goToSettings(Stage primaryStage) {
        PatientSettings PSettings = new PatientSettings();
        PSettings.start(primaryStage);
    }

    private void logout(Stage primaryStage) {
        // Code to logout
        System.out.println("Logging out...");
        primaryStage.close();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
