package application;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.time.LocalDate;
public class DoctorAppointments {
	public static void appDrPage(Stage primaryStage) {
		// Navigation panel on the left
		VBox navPanel = new VBox(10);
		navPanel.setPadding(new Insets(15));
		navPanel.setStyle("-fx-background-color: #E8E8E8;");
		navPanel.setPrefWidth(150);
		Button homeButton = new Button("HOME");	
        homeButton.setPrefWidth(150);
        homeButton.setPrefHeight(550);
        
        Button patientButton = new Button("PATIENTS");
        patientButton.setPrefWidth(150);
        patientButton.setPrefHeight(550);
        
        Button pharmacyButton  = new Button("PHARMACY");
        pharmacyButton.setPrefWidth(150);
        pharmacyButton.setPrefHeight(550);
        
        Button appButton = new Button("APPOINTMENTS");	
        appButton.setPrefWidth(150);
        appButton.setPrefHeight(550);
        
        Button messageButton = new Button("MESSAGE");
        messageButton.setPrefWidth(150);
        messageButton.setPrefHeight(550);
        
        Button profileButton = new Button("PROFILE");
        profileButton.setPrefWidth(150);
        profileButton.setPrefHeight(550);
        
        Button settingsButton = new Button("SETTINGS");		
        settingsButton.setPrefWidth(150);
        settingsButton.setPrefHeight(550);
        
        Button logOutButton = new Button("LOG OUT");
        logOutButton.setPrefWidth(150);
        logOutButton.setPrefHeight(550);

        navPanel.getChildren().addAll(homeButton, patientButton, pharmacyButton, appButton, messageButton, profileButton, settingsButton, logOutButton);
        
 patientButton.setOnAction(e -> DoctorPatientsRegistered.patientsDrView(primaryStage));
        
        
     	homeButton.setOnAction(e -> DoctorHomePage.doctorPOV(primaryStage));
        pharmacyButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));
        profileButton.setOnAction(e -> DoctorProfile.drProfilePage(primaryStage));
        settingsButton.setOnAction(e -> DoctorSettings.drSettingsPage(primaryStage));
        
        //appointmenrds
        appButton.setOnAction(e -> DoctorAppointments.appDrPage(primaryStage));
        
        
        
        //set up the messageing page
        messageButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));
        //send back to the home page
        logOutButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));

		// Appointments heading and date picker
        Label headingLabel = new Label("Appointments");
        headingLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        DatePicker datePicker = new DatePicker(LocalDate.now());
        datePicker.setEditable(false);

        VBox appointmentsPanel = new VBox(10);
        appointmentsPanel.setAlignment(Pos.TOP_CENTER);
        appointmentsPanel.setPadding(new Insets(15));
        appointmentsPanel.getChildren().addAll(headingLabel, datePicker);

        VBox appointmentList = new VBox(10);
        appointmentList.setPadding(new Insets(5));

        Button loadButton = new Button("Load Appointments");
        loadButton.setOnAction(e -> {
            appointmentList.getChildren().clear(); // Clear previous appointments
            String selectedDate = datePicker.getValue().format(DateTimeFormatter.ofPattern("MMddyyyy"));
            String fileName = selectedDate + "_appointments.txt";
            List<String> appointments = readAppointmentsFromFile(fileName);
            
            if (appointments.isEmpty()) {
                // If there are no appointments (file doesn't exist or is empty), display a message
                Label noAppointmentsLabel = new Label("No Appointments for the selected date");
                appointmentList.getChildren().add(noAppointmentsLabel);
            } else {
                // If there are appointments, create a checkbox for each and add it to the list
                for (String appointment : appointments) {
                    CheckBox checkBox = new CheckBox(appointment);
                    appointmentList.getChildren().add(checkBox);
                }
            }
        });

        appointmentsPanel.getChildren().addAll(loadButton, appointmentList);

        // Back button
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> DoctorHomePage.doctorPOV(primaryStage));
        appointmentsPanel.getChildren().add(backButton);

        appointmentsPanel.setAlignment(Pos.CENTER);
        // Main layout
        HBox mainLayout = new HBox(navPanel, appointmentsPanel);
        Stop[] stops = new Stop[]{new Stop(0, Color.LIGHTSTEELBLUE), new Stop(1, Color.WHITE)};
        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        mainLayout.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #B0C4DE, white);");
        //mainLayout.setPadding(new Insets(15));

        // Set the scene and stage
        Scene scene = new Scene(mainLayout, 800, 420);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Appointments");
        primaryStage.show();
	}
	
	private static List<String> readAppointmentsFromFile(String fileName) {
        List<String> appointments = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                appointments.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
            // You might want to alert the user that the file couldn't be read or does not exist
        }
        return appointments;
    }

}
