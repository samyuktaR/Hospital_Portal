
package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Stage;
import javafx.geometry.Pos;

public class NurseProfile {
	
	public static void nurseProfilePage(Stage primaryStage) {
        // Menu Buttons on the left side
        VBox menuButtons = new VBox(10);
        menuButtons.setPadding(new Insets(10));
        menuButtons.setStyle("-fx-background-color: #f0f0f0;");
        Button homeButton = new Button("HOME");
        homeButton.setPrefWidth(150);
        homeButton.setPrefHeight(550);
        
        Button patientsButton = new Button("PATIENTS");
        patientsButton.setPrefWidth(150);
        patientsButton.setPrefHeight(550);
        
        Button appointmentsButton = new Button("APPOINTMENTS");
        appointmentsButton.setPrefWidth(150);
        appointmentsButton.setPrefHeight(550);
        
        Button messageButton = new Button("MESSAGE");
        messageButton.setPrefWidth(150);
        messageButton.setPrefHeight(550);
        
        Button profileButton = new Button("PROFILE");
        profileButton.setPrefWidth(150);
        profileButton.setPrefHeight(550);
        
        Button settingsButton = new Button("SETTINGS");
        settingsButton.setPrefWidth(150);
        settingsButton.setPrefHeight(550);
        
        Button logOutButton = new Button("LOG OUT");
        logOutButton.setPrefWidth(150);
        logOutButton.setPrefHeight(550);
        
        menuButtons.getChildren().addAll(
            homeButton, patientsButton, appointmentsButton,
            messageButton, profileButton, settingsButton, logOutButton
        );
        
        logOutButton.setOnAction(e -> {
        	Main main = new Main();
        	main.start(primaryStage);
        });
        
        homeButton.setOnAction(e -> NurseHomePage.homePageNurse(primaryStage));
        
        patientsButton.setOnAction(e -> NurseViewPateints.PatientNames(primaryStage));
        
        profileButton.setOnAction(e -> NurseProfile.nurseProfilePage(primaryStage));
        
        settingsButton.setOnAction(e -> NurseSettings.nurseSettingsPage(primaryStage));

        // Profile Form on the right
        GridPane profileForm = new GridPane();
        profileForm.setHgap(10);
        profileForm.setVgap(10);
        profileForm.setPadding(new Insets(20));
        profileForm.setAlignment(Pos.TOP_CENTER);

        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField("Lizzie Marshall");
        Label ageLabel = new Label("Age:");
        TextField ageField = new TextField("35");
        Label educationLabel = new Label("Education:");
        TextField educationField = new TextField("Stanford University");
        Label aboutLabel = new Label("About:");
        TextArea aboutField = new TextArea("Compassionate, diligent, and dedicated");
        //Button editButton = new Button("Edit");
        
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> NurseHomePage.homePageNurse(primaryStage));
        
        profileForm.add(nameLabel, 0, 0);
        profileForm.add(nameField, 1, 0);
        profileForm.add(ageLabel, 0, 1);
        profileForm.add(ageField, 1, 1);
        profileForm.add(educationLabel, 0, 2);
        profileForm.add(educationField, 1, 2);
        profileForm.add(aboutLabel, 0, 3);
        profileForm.add(aboutField, 1, 3);
        profileForm.add(backButton, 0, 5);
        //profileForm.add(editButton, 1, 5);

        // Main layout
        HBox mainLayout = new HBox(10);
        mainLayout.getChildren().addAll(menuButtons, profileForm);
        
        Stop[] stops = new Stop[]{new Stop(0, Color.LIGHTBLUE), new Stop(1, Color.WHITE)};
        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        mainLayout.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #add8e6, white);");

        // Set the scene
        Scene scene = new Scene(mainLayout, 800, 420);

        // Stage settings
        primaryStage.setTitle("User Profile");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


  
}