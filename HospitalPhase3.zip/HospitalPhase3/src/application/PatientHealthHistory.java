package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PatientHealthHistory extends Application {

    private static final String HEALTH_HISTORY_FILE_PATH = "health_history.txt";

    private TextArea allergiesTextArea;
    private TextArea medicationsTextArea;
    private TextArea conditionsTextArea;
    private ImageView immunizationImageView;
    private Button updateButton;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Health History");

        // Components for Health History Page
        Label titleLabel = new Label("MY HEALTH HISTORY");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        allergiesTextArea = new TextArea();
        medicationsTextArea = new TextArea();
        conditionsTextArea = new TextArea();
        immunizationImageView = new ImageView();
        immunizationImageView.setFitWidth(200); // Set a smaller fixed width
        immunizationImageView.setPreserveRatio(true); // Preserve the aspect ratio

        loadHealthHistory(); // Load health history from file

        Label allergiesLabel = new Label("Allergies:");
        Label medicationsLabel = new Label("Medications:");
        Label conditionsLabel = new Label("Medical Conditions:");
        Label immunizationLabel = new Label("Immunization Record");

        Button uploadButton = new Button("UPLOAD FILE");
        uploadButton.setOnAction(e -> uploadFile(primaryStage));

        updateButton = new Button("UPDATE");
        updateButton.setOnAction(e -> saveHealthHistory()); // Save health history to file

        // Sidebar menu components
        Button homeButton = new Button("HOME");
        Button profileButton = new Button("PROFILE");
        Button healthHistoryButton = new Button("HEALTH HISTORY");
        Button appointmentsButton = new Button("APPOINTMENTS");
        Button visitSummaryButton = new Button("VISIT SUMMARY");
        Button messagesButton = new Button("MESSAGES");
        Button settingsButton = new Button("SETTINGS");
        Button logoutButton = new Button("LOG OUT");

        // Set fixed size for all buttons in the sidebar menu
        double buttonWidth = 150;
        double buttonHeight = 40;
        homeButton.setPrefSize(buttonWidth, buttonHeight);
        profileButton.setPrefSize(buttonWidth, buttonHeight);
        healthHistoryButton.setPrefSize(buttonWidth, buttonHeight);
        appointmentsButton.setPrefSize(buttonWidth, buttonHeight);
        visitSummaryButton.setPrefSize(buttonWidth, buttonHeight);
        messagesButton.setPrefSize(buttonWidth, buttonHeight);
        settingsButton.setPrefSize(buttonWidth, buttonHeight);
        logoutButton.setPrefSize(buttonWidth, buttonHeight);

        // Layout for sidebar menu
        VBox menuLayout = new VBox(10);
        menuLayout.setPadding(new Insets(10));
        menuLayout.getChildren().addAll(homeButton, profileButton, healthHistoryButton,
                appointmentsButton, visitSummaryButton, messagesButton,
                settingsButton, logoutButton);

        VBox healthHistoryContentLayout = new VBox(20);
        healthHistoryContentLayout.setAlignment(Pos.CENTER_LEFT);
        healthHistoryContentLayout.setPadding(new Insets(20));
        healthHistoryContentLayout.getChildren().addAll(titleLabel,
                allergiesLabel, allergiesTextArea,
                medicationsLabel, medicationsTextArea,
                conditionsLabel, conditionsTextArea,
                new HBox(10, immunizationLabel, uploadButton),
                immunizationImageView); // <-- Add ImageView here

        // HBox for Upload and Update buttons
        HBox buttonsLayout = new HBox(10, updateButton, uploadButton); // Switched positions of buttons
        buttonsLayout.setAlignment(Pos.CENTER);
        buttonsLayout.setPadding(new Insets(10, 20, 0, 0)); // Adjusted padding

     // BorderPane to hold the sidebar and content
        BorderPane mainLayout = new BorderPane();
        mainLayout.setLeft(menuLayout);
        mainLayout.setCenter(healthHistoryContentLayout);
        mainLayout.setBottom(buttonsLayout);
        BorderPane.setAlignment(buttonsLayout, Pos.CENTER_LEFT);

        // Set background color to mainLayout
        mainLayout.setStyle("-fx-background-color: linear-gradient(to bottom, #d1e5f0, #a5cbe4);");

        // Event handlers for sidebar buttons
        homeButton.setOnAction(e -> goToHome(primaryStage));
        profileButton.setOnAction(e -> goToProfile(primaryStage));
        healthHistoryButton.setOnAction(e -> goToHealthHistory(primaryStage));
        appointmentsButton.setOnAction(e -> goToAppointments(primaryStage));
        visitSummaryButton.setOnAction(e -> goToVisitSummary(primaryStage));
        messagesButton.setOnAction(e -> goToMessages(primaryStage));
        settingsButton.setOnAction(e -> goToSettings(primaryStage));
        logoutButton.setOnAction(e -> logout(primaryStage));

        Scene scene = new Scene(mainLayout, 700, 500);
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    private void uploadFile(Stage primaryStage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Upload Immunization Record");

        // Set file filters to allow only PDF, JPG, JPEG, or PNG files
        FileChooser.ExtensionFilter pdfFilter = new FileChooser.ExtensionFilter("PDF files (*.pdf)", "*.pdf");
        FileChooser.ExtensionFilter jpgFilter = new FileChooser.ExtensionFilter("JPG files (*.jpg)", "*.jpg");
        FileChooser.ExtensionFilter jpegFilter = new FileChooser.ExtensionFilter("JPEG files (*.jpeg)", "*.jpeg");
        FileChooser.ExtensionFilter pngFilter = new FileChooser.ExtensionFilter("PNG files (*.png)", "*.png");

        fileChooser.getExtensionFilters().addAll(pdfFilter, jpgFilter, jpegFilter, pngFilter);

        File file = fileChooser.showOpenDialog(primaryStage);
        if (file != null) {
            try {
                // Load the image from the selected file
                Image image = new Image(file.toURI().toString());
                // Set the loaded image to the ImageView
                immunizationImageView.setImage(image);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private void goToHome(Stage primaryStage) {
        PatientPortalHomePage homePage = new PatientPortalHomePage();
        homePage.start(primaryStage);
    }

    private void goToProfile(Stage primaryStage) {
        PatientProfile profile = new PatientProfile();
        profile.start(primaryStage);
    }

    private void goToHealthHistory(Stage primaryStage) {
        PatientHealthHistory patientHH = new PatientHealthHistory();
        patientHH.start(primaryStage);
    }

    private void goToAppointments(Stage primaryStage) {
        PatientAppointments patientApps = new PatientAppointments();
        patientApps.start(primaryStage);
    }

    private void goToVisitSummary(Stage primaryStage) {
        PatientVS patientVS = new PatientVS();
        patientVS.start(primaryStage);
    }

    private void goToMessages(Stage primaryStage) {
        PatientMessages patientMessages = new PatientMessages();
        patientMessages.start(primaryStage);
    }

    private void goToSettings(Stage primaryStage) {
        PatientSettings patientSettings = new PatientSettings();
        patientSettings.start(primaryStage);
    }

    private void logout(Stage primaryStage) {
        System.out.println("Logging out...");
        primaryStage.close();
    }

    private void saveHealthHistory() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(HEALTH_HISTORY_FILE_PATH))) {
            writer.println(allergiesTextArea.getText());
            writer.println(medicationsTextArea.getText());
            writer.println(conditionsTextArea.getText());
            // You need to save the image separately if needed
        } catch (IOException e) {
            e.printStackTrace();
            // Handle file writing error
        }
    }

    private void loadHealthHistory() {
        try (BufferedReader reader = new BufferedReader(new FileReader(HEALTH_HISTORY_FILE_PATH))) {
            List<String> lines = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            if (lines.size() >= 3) {
                allergiesTextArea.setText(lines.get(0));
                medicationsTextArea.setText(lines.get(1));
                conditionsTextArea.setText(lines.get(2));
                // Load image if needed
            }
        } catch (IOException e) {
            e.printStackTrace();
            // Handle file reading error
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
