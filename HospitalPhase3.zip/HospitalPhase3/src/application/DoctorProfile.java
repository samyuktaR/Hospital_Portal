package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Stage;
import javafx.geometry.Pos;

public class DoctorProfile {
	
	public static void drProfilePage(Stage primaryStage) {
        // Menu Buttons on the left side
        VBox vBoxLeft = new VBox(10);
        vBoxLeft.setPadding(new Insets(10));
        vBoxLeft.setStyle("-fx-background-color: #f0f0f0;");
        Button homeButton = new Button("HOME");	
        homeButton.setPrefWidth(150);
        homeButton.setPrefHeight(550);
        
        Button patientButton = new Button("PATIENTS");
        patientButton.setPrefWidth(150);
        patientButton.setPrefHeight(550);
        
        Button pharmacyButton  = new Button("PHARMACY");
        pharmacyButton.setPrefWidth(150);
        pharmacyButton.setPrefHeight(550);
        
        Button appButton = new Button("APPOINTMENTS");	
        appButton.setPrefWidth(150);
        appButton.setPrefHeight(550);
        
        Button messageButton = new Button("MESSAGE");
        messageButton.setPrefWidth(150);
        messageButton.setPrefHeight(550);
        
        Button profileButton = new Button("PROFILE");
        profileButton.setPrefWidth(150);
        profileButton.setPrefHeight(550);
        
        Button settingsButton = new Button("SETTINGS");		
        settingsButton.setPrefWidth(150);
        settingsButton.setPrefHeight(550);
        
        Button logOutButton = new Button("LOG OUT");
        logOutButton.setPrefWidth(150);
        logOutButton.setPrefHeight(550);

        vBoxLeft.getChildren().addAll(homeButton, patientButton, pharmacyButton, appButton, messageButton, profileButton, settingsButton, logOutButton);
        
        //show the patient list
        patientButton.setOnAction(e -> DoctorPatientsRegistered.patientsDrView(primaryStage));
        
        
        homeButton.setOnAction(e -> DoctorHomePage.doctorPOV(primaryStage));
        pharmacyButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));
        profileButton.setOnAction(e -> DoctorProfile.drProfilePage(primaryStage));
        settingsButton.setOnAction(e -> DoctorSettings.drSettingsPage(primaryStage));
        
        //appointments
        appButton.setOnAction(e -> DoctorAppointments.appDrPage(primaryStage));
        
        
        
        //set up the messageing page
        messageButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));
        //send back to the home page
        logOutButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));
        
        
        
        

        // Profile Form on the right
        GridPane profileForm = new GridPane();
        profileForm.setHgap(10);
        profileForm.setVgap(10);
        profileForm.setPadding(new Insets(20));
        profileForm.setAlignment(Pos.TOP_CENTER);

        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();
        Label ageLabel = new Label("Age:");
        TextField ageField = new TextField();
        Label educationLabel = new Label("Education:");
        TextField educationField = new TextField();
        Label aboutLabel = new Label("About:");
        TextArea aboutField = new TextArea();
        Button editProfileButton = new Button("Edit Profile Photo");
        Button editButton = new Button("Edit");
        Button backButton = new Button("Back");
        
        profileForm.add(nameLabel, 0, 0);
        profileForm.add(nameField, 1, 0);
        profileForm.add(ageLabel, 0, 1);
        profileForm.add(ageField, 1, 1);
        profileForm.add(educationLabel, 0, 2);
        profileForm.add(educationField, 1, 2);
        profileForm.add(aboutLabel, 0, 3);
        profileForm.add(aboutField, 1, 3);
        profileForm.add(editProfileButton, 1, 4);
        profileForm.add(backButton, 0, 5);
        profileForm.add(editButton, 1, 5);

        // Main layout
        HBox mainLayout = new HBox(10);
        mainLayout.getChildren().addAll(vBoxLeft, profileForm);
        Stop[] stops = new Stop[]{new Stop(0, Color.LIGHTSTEELBLUE), new Stop(1, Color.WHITE)};
        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        mainLayout.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #B0C4DE, white);");

        // Set the scene
        Scene scene = new Scene(mainLayout, 800, 420);

        // Stage settings
        primaryStage.setTitle("User Profile");
        primaryStage.setScene(scene);
        primaryStage.show();
    }


  
}
