package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Stage;

public class DoctorHomePage {

	//private Scene scene;
	
    
    public static void doctorPOV(Stage primaryStage) {
        // Left section with buttons using VBox
        VBox vBoxLeft = new VBox(10);
        vBoxLeft.setPadding(new Insets(15));
       
        Button homeButton = new Button("HOME");	
        homeButton.setPrefWidth(150);
        homeButton.setPrefHeight(550);
        
        Button patientButton = new Button("PATIENTS");
        patientButton.setPrefWidth(150);
        patientButton.setPrefHeight(550);
        
        Button pharmacyButton  = new Button("PHARMACY");
        pharmacyButton.setPrefWidth(150);
        pharmacyButton.setPrefHeight(550);
        
        Button appButton = new Button("APPOINTMENTS");	
        appButton.setPrefWidth(150);
        appButton.setPrefHeight(550);
        
        Button messageButton = new Button("MESSAGE");
        messageButton.setPrefWidth(150);
        messageButton.setPrefHeight(550);
        
        Button profileButton = new Button("PROFILE");
        profileButton.setPrefWidth(150);
        profileButton.setPrefHeight(550);
        
        Button settingsButton = new Button("SETTINGS");		
        settingsButton.setPrefWidth(150);
        settingsButton.setPrefHeight(550);
        
        Button logOutButton = new Button("LOG OUT");
        logOutButton.setPrefWidth(150);
        logOutButton.setPrefHeight(550);

        vBoxLeft.getChildren().addAll(homeButton, patientButton, pharmacyButton, appButton, messageButton, profileButton, settingsButton, logOutButton);
        
        //show the patient list
        patientButton.setOnAction(e -> DoctorPatientsRegistered.patientsDrView(primaryStage));
        
        
        homeButton.setOnAction(e -> DoctorHomePage.doctorPOV(primaryStage));
        pharmacyButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));
        profileButton.setOnAction(e -> DoctorProfile.drProfilePage(primaryStage));
        settingsButton.setOnAction(e -> DoctorSettings.drSettingsPage(primaryStage));
        
        //appointments
        appButton.setOnAction(e -> DoctorAppointments.appDrPage(primaryStage));
        
        
        
        //set up the messageing page
        messageButton.setOnAction(e -> DoctorMessaging.messagePatient(primaryStage));
        //send back to the home page
        logOutButton.setOnAction(e -> DoctorPharmacy.pharmacyView(primaryStage));
       
        
        

        // Middle section
        VBox vBoxMiddle = new VBox(10);
        vBoxMiddle.setPadding(new Insets(15));

        // Welcome message
        Label welcomeLabel = new Label("Welcome Dr. Chay!");
        welcomeLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        vBoxMiddle.getChildren().add(welcomeLabel);

        // To-do list using checkboxes
        VBox checkBoxList = new VBox(5);
        CheckBox checkBox1 = new CheckBox("Follow up for Felix Johnson");
        CheckBox checkBox2 = new CheckBox("Lunch with Dr. Jones");
        CheckBox checkBox3 = new CheckBox("Call Mr. Freeman");
        checkBoxList.getChildren().addAll(checkBox1, checkBox2, checkBox3);
        vBoxMiddle.getChildren().add(checkBoxList);

        // Text area for journal
        TextArea journalTextArea = new TextArea();
        journalTextArea.setPromptText("Type here");
        journalTextArea.setPrefHeight(100);
        Button saveButton = new Button("Save");
        Button clearButton = new Button("Clear All");
        HBox journalButtons = new HBox(5, saveButton, clearButton);
        vBoxMiddle.getChildren().addAll(journalTextArea, journalButtons);

        
        // Right section with buttons
        VBox vBoxRight = new VBox(10);
        vBoxRight.setPadding(new Insets(15));
        Button emailsButton = new Button("Emails");
        Button googleButton = new Button("Google");
        Button calculatorButton = new Button("Calculator");
        vBoxRight.getChildren().addAll(emailsButton, googleButton, calculatorButton);

        // Setting the sizes for the buttons
        emailsButton.setPrefWidth(150);
        googleButton.setPrefWidth(150);
        calculatorButton.setPrefWidth(150);
        
        // Main layout using HBox
        HBox mainLayout = new HBox(0, vBoxLeft, vBoxMiddle, vBoxRight);
        Stop[] stops = new Stop[]{new Stop(0, Color.LIGHTSTEELBLUE), new Stop(1, Color.WHITE)};
        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        mainLayout.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #B0C4DE, white);");
        
        // Set the scene and show the stage
        Scene scene = new Scene(mainLayout, 800, 420);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Doctor's Dashboard");
        primaryStage.show();
    }
    
}
