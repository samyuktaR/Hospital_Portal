package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class StaffLoginPortal {

    public static void loginportalStaff(Stage primaryStage) {
        // Main layout pane
        VBox mainLayout = new VBox(10);
        mainLayout.setAlignment(Pos.CENTER);
        mainLayout.setPadding(new Insets(30));
        
        Stop[] stops = new Stop[]{new Stop(0, Color.CORNFLOWERBLUE), new Stop(1, Color.WHITE)};
        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        mainLayout.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #6495ED, white);");

        // Title
        Label titleLabel = new Label("STAFF PORTAL");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));

        // Username input
        HBox usernameBox = new HBox(10);
        usernameBox.setAlignment(Pos.CENTER);
        Label usernameLabel = new Label("USER NAME:");
        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        usernameBox.getChildren().addAll(usernameLabel, usernameField);       
        
        // Password input
        HBox passwordBox = new HBox(10);
        passwordBox.setAlignment(Pos.CENTER);
        Label passwordLabel = new Label("PASSWORD:");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordBox.getChildren().addAll(passwordLabel, passwordField);

        // Login buttons
        HBox buttonBox = new HBox(40);
        buttonBox.setAlignment(Pos.CENTER);
        Button doctorButton = new Button("Doctor");
        Button nurseButton = new Button("Nurse");
        buttonBox.getChildren().addAll(doctorButton, nurseButton);

        // Back button (for UI purposes, no functionality defined)
        Button backButton = new Button("Back");
        backButton.setStyle("-fx-font-size: 16px;");

        doctorButton.setOnAction(e -> {
            if (usernameField.getText().equals("Chay") && passwordField.getText().equals("1234")) {
            DoctorHomePage.doctorPOV(primaryStage);
            } 
        });
        
        
        nurseButton.setOnAction(e -> {
            if (usernameField.getText().equals("Sam") && passwordField.getText().equals("asd")) {
            NurseHomePage.homePageNurse(primaryStage);
            } 
        });
        
        // Add all elements to the main layout
        mainLayout.getChildren().addAll(titleLabel, usernameBox, passwordBox, buttonBox); //, backButton);

        // Create scene and stage
        Scene scene = new Scene(mainLayout, 800, 420);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Login - Staff Portal");
        primaryStage.show();
    }

}
