
package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Stage;

import java.time.LocalDate;


public class NurseHomePage {

    
    public static void homePageNurse(Stage primaryStage) {
        // Left section with buttons using VBox
        VBox vBoxLeft = new VBox(10);
        vBoxLeft.setPadding(new Insets(15));
        String[] buttonLabels = {"HOME", "PATIENTS", "APPOINTMENTS", "MESSAGE", "PROFILE", "SETTINGS", "LOG OUT"};
        for (String label : buttonLabels) {
            Button button = new Button(label);
            button.setPrefWidth(150);
            button.setPrefHeight(550);
            vBoxLeft.getChildren().add(button);
            
            if(label.equals("LOG OUT")) {
            	button.setOnAction(e -> {
            		Main main = new Main();
            		main.start(primaryStage);
            	});
            }
            
            if(label.equals("PROFILE")) {
            	button.setOnAction(e -> NurseProfile.nurseProfilePage(primaryStage));
            }
            
            if(label.equals("PATIENTS")) {
				button.setOnAction(e -> NurseViewPateints.PatientNames(primaryStage));
			}
            
            if(label.equals("SETTINGS")) {
            	button.setOnAction(e -> NurseSettings.nurseSettingsPage(primaryStage));
            }
        }

        // Middle section
        VBox vBoxMiddle = new VBox(10);
        vBoxMiddle.setPadding(new Insets(15));

        // Welcome message
        Label welcomeLabel = new Label("Welcome Lizzie!");
        welcomeLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        vBoxMiddle.getChildren().add(welcomeLabel);

        // To-do list using checkboxes
        VBox checkBoxList = new VBox(5);
        CheckBox checkBox1 = new CheckBox("Follow up with Emily Watts for consult");
        CheckBox checkBox2 = new CheckBox("Contact pharmacy regarding injection stock");
        CheckBox checkBox3 = new CheckBox("Call Mr. Lee");
        checkBoxList.getChildren().addAll(checkBox1, checkBox2, checkBox3);
        vBoxMiddle.getChildren().add(checkBoxList);

        TextArea addReminder = new TextArea();
        addReminder.setPromptText("Type reminders here");
        addReminder.setPrefHeight(50);
        
        // Text area for journal
        TextArea notesTextArea = new TextArea();
        notesTextArea.setPromptText("Type notes here");
        notesTextArea.setPrefHeight(100);
        Button saveButton = new Button("Save");
        Button clearButton = new Button("Clear All");
        Button reminderButton = new Button("Add Reminder");
        HBox notesButtons = new HBox(5, saveButton, clearButton, reminderButton);
        vBoxMiddle.getChildren().addAll(addReminder, notesTextArea, notesButtons);
        
        // Right section with buttons
        VBox vBoxRight = new VBox(10);
        vBoxRight.setPadding(new Insets(15));
        
        DatePicker datePicker = new DatePicker(LocalDate.now());
		datePicker.setEditable(false);
		vBoxRight.getChildren().add(datePicker);
        
        // Main layout using HBox
        HBox mainLayout = new HBox(0, vBoxLeft, vBoxMiddle, vBoxRight);
        
        Stop[] stops = new Stop[]{new Stop(0, Color.LIGHTBLUE), new Stop(1, Color.WHITE)};
        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        mainLayout.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #add8e6, white);");
        
        // Set the scene and show the stage
        Scene scene = new Scene(mainLayout, 800, 420);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Nurse's Portal");
        primaryStage.show();
    }

}