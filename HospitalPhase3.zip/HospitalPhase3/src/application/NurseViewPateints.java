
package application;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Stage;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.List;
import java.io.File;
import java.io.*;
import javafx.scene.control.Alert;

public class NurseViewPateints {
	
	private static String selectedPatientName;
	
	public static void PatientNames(Stage stage) {
		VBox leftColumn = new VBox(10);
		leftColumn.setPadding(new Insets(15));
		String[] buttonLabels = {"HOME", "PATIENTS", "APPOINTMENTS", "MESSAGE", "PROFILE", "SETTINGS", "LOG OUT"};
		for (String label : buttonLabels) {
			Button button = new Button(label);
			button.setPrefWidth(150);
			button.setPrefHeight(550);
			leftColumn.getChildren().add(button);
			
			if(label.equals("LOG OUT")) {
	        	button.setOnAction(e -> {
	        		Main main = new Main();
	        		main.start(stage);
	        	});
	        }
			
			if(label.equals("HOME")) {
				button.setOnAction(e -> NurseHomePage.homePageNurse(stage));
			}
			
			if(label.equals("SETTINGS")) {
				button.setOnAction(e -> NurseSettings.nurseSettingsPage(stage));
			}
			
			if(label.equals("PROFILE")) {
				button.setOnAction(e -> NurseProfile.nurseProfilePage(stage));
			}
		}	
		
		VBox rightColumn = new VBox(10);
		rightColumn.setPadding(new Insets(15));
        
        Label welcomeLabel = new Label("Patients");
        welcomeLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        rightColumn.getChildren().add(welcomeLabel);
        
        TextArea searchBar = new TextArea();
        searchBar.setPromptText("Enter Patient ID to search");
        searchBar.setPrefHeight(5);
        
        Button searchPatient = new Button("Search");
        searchPatient.setOnAction(e -> {
            String patientInfoFileName = searchBar.getText() + "_PatientInfo.txt";
            File patientInfoFile = new File(patientInfoFileName);
            if (patientInfoFile.exists() && !searchBar.getText().trim().isEmpty()) {
                // Read the content of the file
                String content = "";
                try {
                    content = new String(Files.readAllBytes(Paths.get(patientInfoFileName)));
                } catch (IOException ex) {
                    ex.printStackTrace();
                    // You can alert the user that there was an error reading the file.
                    content = "Error reading patient info.";
                }

                // Display the content in an alert dialog
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Patient Information");
                alert.setHeaderText("Information for Patient ID: " + searchBar.getText());

                TextArea textArea = new TextArea(content.toString());
                textArea.setEditable(false);
                textArea.setWrapText(true);
                
                alert.getDialogPane().setContent(textArea);

                alert.showAndWait();
            }
        });
        
        ListView<String> patientList = new ListView<>();
        try {
            // Replace "RegisteredPatientNames.txt" with the correct path if needed
            List<String> names = Files.readAllLines(Paths.get("RegisteredPatientNames.txt"));
            patientList.getItems().addAll(names);
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception here
        }
        patientList.setPrefHeight(200);
        patientList.setOnMouseClicked(event -> {
        	selectedPatientName = patientList.getSelectionModel().getSelectedItem();
        });
        Button addButton = new Button("Add New");
        addButton.setOnAction(e -> NurseRegPatient.patientRecepPage(stage));
        
        Button takeExamButton = new Button("Take Patient Exam");
        takeExamButton.setOnAction( e -> {
        	String selectedPatientName = NurseViewPateints.getSelectedPatientName(); 
        	if(selectedPatientName != null) {
        		NurseExamPatient exam = new NurseExamPatient();
        		exam.setSelectedPatientName(selectedPatientName);
        		exam.start(stage);
        	}
        });
        
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> NurseHomePage.homePageNurse(stage));
        HBox notesButtons = new HBox(20, backButton, addButton, takeExamButton);
        rightColumn.getChildren().addAll(searchBar, searchPatient, patientList, notesButtons);
        
        HBox mainLayout = new HBox(0, leftColumn, rightColumn);
        
        Stop[] stops = new Stop[]{new Stop(0, Color.LIGHTBLUE), new Stop(1, Color.WHITE)};
        LinearGradient gradient = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, stops);
        mainLayout.setStyle("-fx-background-color: linear-gradient(from 0% 0% to 100% 100%, #add8e6, white);");
        
        Scene scene = new Scene(mainLayout, 800, 420);
        stage.setScene(scene);
        stage.setTitle("Nurse's Portal");
        stage.show();
	}
	
	public static String getSelectedPatientName() {
		return selectedPatientName;
	}
}