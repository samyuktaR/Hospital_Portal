package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class PatientPortal extends Application {

    private static final String USER_FILE_PATH = "users.txt";

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Patient Portal");

        Label titleLabel = new Label("Patient Portal");
        titleLabel.setFont(Font.font("Arial", 24));
        titleLabel.setAlignment(Pos.CENTER);
        titleLabel.setStyle("-fx-font-weight: bold;");

        TextField firstNameField = new TextField();
        firstNameField.setPromptText("First Name");
        TextField lastNameField = new TextField();
        lastNameField.setPromptText("Last Name");
        TextField birthDateField = new TextField();
        birthDateField.setPromptText("Birth Date");
        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        TextField passwordField = new TextField();
        passwordField.setPromptText("Password");

        Button createAccountButton = new Button("Create Account");
        createAccountButton.setStyle("-fx-background-color: purple; -fx-text-fill: white;");
        Button signInButton = new Button("Sign In");
        signInButton.setStyle("-fx-background-color: purple; -fx-text-fill: white;");

        createAccountButton.setOnAction(e -> {
            // Add logic to create account
            createUserAccount(firstNameField.getText(), lastNameField.getText(), birthDateField.getText(),
                    usernameField.getText(), passwordField.getText());
            showSignInPage(primaryStage);
        });

        signInButton.setOnAction(e -> showSignInPage(primaryStage));

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().addAll(createAccountButton, signInButton);

        VBox layout = new VBox(10);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));
        layout.getChildren().addAll(titleLabel, firstNameField, lastNameField, birthDateField, usernameField,
                passwordField, buttonBox);

        StackPane root = new StackPane();
        root.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, null, null)));
        root.setPadding(new Insets(10, 10, 10, 10)); // Padding for the top, right, bottom, and left sides
        root.getChildren().addAll(layout);

        Scene scene = new Scene(root, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void showSignInPage(Stage primaryStage) {
        PatientSignIn patientSignIn = new PatientSignIn();
        patientSignIn.start(primaryStage);
    }

    private void createUserAccount(String firstName, String lastName, String birthDate, String username,
            String password) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USER_FILE_PATH, true))) {
            writer.write(username + "," + password + "," + firstName + "," + lastName + "," + birthDate);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
            // Handle file writing error
        }
    }
}

class PatientSignIn extends Application {

	private static final String USER_FILE_PATH = "users.txt";

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Sign In");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        TextField passwordField = new TextField();
        passwordField.setPromptText("Password");

        Button signInButton = new Button("Sign In");
        signInButton.setStyle("-fx-background-color: purple; -fx-text-fill: white;");
        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: purple; -fx-text-fill: white;");

        signInButton.setOnAction(e -> {
            String enteredUsername = usernameField.getText();
            String enteredPassword = passwordField.getText();
            if (verifyCredentials(enteredUsername, enteredPassword)) {
                // Navigate to home page if credentials are valid
                goToHomePage(primaryStage);
            } else {
                // Display error message and stay on sign-in page
                showErrorDialog();
            }
        });

        backButton.setOnAction(e -> primaryStage.close());

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().addAll(signInButton, backButton);

        VBox layout = new VBox(10);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));
        layout.getChildren().addAll(usernameField, passwordField, buttonBox);

        StackPane root = new StackPane();
        root.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, null, null)));
        root.setPadding(new Insets(10, 10, 10, 10)); // Padding for the top, right, bottom, and left sides
        root.getChildren().addAll(layout);

        Scene scene = new Scene(root, 400, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private boolean verifyCredentials(String enteredUsername, String enteredPassword) {
        try (BufferedReader reader = new BufferedReader(new FileReader(USER_FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5 && parts[0].equals(enteredUsername) && parts[1].equals(enteredPassword)) {
                    return true; // Credentials match
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            // Handle file reading error
        }
        return false; // Credentials do not match
    }

    private void goToHomePage(Stage primaryStage) {
        PatientPortalHomePage homePage = new PatientPortalHomePage();
        homePage.start(primaryStage);
    }

    private void showErrorDialog() {
        // Display error message
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText("Invalid username or password. Try again.");
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}